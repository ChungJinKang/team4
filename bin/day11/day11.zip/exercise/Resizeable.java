package day11.exercise;

public interface Resizeable {
	public void resize(double s);
}
