package day11;

public interface Resizeable {
	void resize(double i);
}
