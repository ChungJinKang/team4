package day11.tv;

public interface TV {
	public void powerOn();
	public void powerOff();
	
}
