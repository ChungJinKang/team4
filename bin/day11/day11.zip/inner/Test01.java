package day11.inner;

public class Test01 {

	public static void main(String[] args) {
		B b = new B(new A());
		b.print();
	}

}
