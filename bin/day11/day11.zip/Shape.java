package day11;

public abstract class Shape {
	public abstract double getArea();
}
