package day11.exercise2;

class Outer {
	class Inner {
		int iv = 100;
	}
}
